export enum ModalEnum{
  BookingSummaryModal = "BookingSummaryModal"
}