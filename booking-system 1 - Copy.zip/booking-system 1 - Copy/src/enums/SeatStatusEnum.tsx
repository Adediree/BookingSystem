export enum SeatStatusEnum{
  AVAILABLE = "available",
  BOOKED = "booked"
}