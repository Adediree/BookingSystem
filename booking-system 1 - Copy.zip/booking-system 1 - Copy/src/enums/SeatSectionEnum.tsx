export enum SeatSectionEnum{
  Senegal = "SENEGAL",
  Ghana = "GHANA",
  Namibia = "NAMIBIA",
  Kenya = "KENYA",
  Etiopia = "ETIOPIA",
  Togo = "TOGO",
  Mali = "MALI",
  Zambia = "ZAMBIA",
}